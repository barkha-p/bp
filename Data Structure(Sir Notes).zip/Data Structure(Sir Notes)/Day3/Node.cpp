#include <iostream>
#include <string>
using namespace std;

struct Node{
	int num;
	string name;
	Node *next;	
};

int main(){
	Node *ptr;
	ptr = new Node();
	ptr->num=10;
	ptr->name = "Some name here";
	ptr->next = 0;
	
	cout<<"Num: "<<ptr->num;
	cout<<"\tName: "<<ptr->name;
	cout<<"\tNext: "<<ptr->next<<endl;
}

