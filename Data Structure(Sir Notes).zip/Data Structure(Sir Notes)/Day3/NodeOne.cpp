#include <iostream>
#include <string>
using namespace std;

struct Node{
	int num;
	string name;
	Node *ptr;	
};

int main(){
	Node *ptr;
	ptr = new Node();
	ptr->num=10;
	ptr->name = "Some name here";
	ptr->ptr = 0;
	cout<<"Ptr: "<<ptr<<endl;
	cout<<"\tNum: "<<ptr->num<<endl;
	cout<<"\tName: "<<ptr->name;
	cout<<"\tptr: "<<ptr->ptr<<endl;
}

