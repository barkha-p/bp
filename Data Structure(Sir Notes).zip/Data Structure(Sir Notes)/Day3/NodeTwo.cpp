#include <iostream>
#include <string>
using namespace std;

struct Node{ //self referencial struct
	int num;
	string name;
	Node *ptr;	
};

int main(){
	Node *ptr;
	ptr = new Node();
	ptr->num=10;
	ptr->name = "Some name here";
	ptr->ptr = ptr;
	cout<<"Ptr: "<<ptr<<endl;
	cout<<"Num: "<<ptr->ptr->ptr->ptr->ptr->ptr->ptr->num<<endl;
	cout<<"Name: "<<ptr->ptr->name;
	cout<<"\tptr: "<<ptr->ptr->ptr<<endl;
	
	
}

