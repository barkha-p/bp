int main(){
	for(int i=0;i<MAX;i++)
		for(int j=0;j<MAX;j++)//2n+1
			;

}



