#include <iostream>
using namespace std;

int main(){
	unsigned long long num;
	for(int cnt=0;cnt<64;cnt++){
		num=1<<cnt;
		cout<<2<<"^"<<cnt<<"-->"<<num<<endl;
	}
	
}
