#include <iostream>
using namespace std;

int main(){
	cout<<"Sizeof(long): "<<sizeof(long long)<<endl;
}