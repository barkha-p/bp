#include <iostream>
#include <cctype>
using namespace std;

int main(){
	int arr[100],pos=0,sign=0;
	char ch;
	cin.get(ch);
	if(ch=='-')
		sign=1;
	else if(isdigit(ch))
		arr[pos++] = ch-'0';

	if(sign)
		cout<<'-';
	else
		cout<<'+';

	while(cin.get(ch)){
		if(isdigit(ch)){
			arr[pos++] = ch -'0';
		}else 
			break;
	}
		
	for(int cnt=0;cnt<pos;cnt++)
		cout<<arr[cnt]<<" ";
	cout<<endl;
}
