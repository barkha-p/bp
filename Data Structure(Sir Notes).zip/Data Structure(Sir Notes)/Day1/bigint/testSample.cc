#include <string>
#include <iostream>


#include "BigIntegerLibrary.hh"

int main() {
	try {
		BigUnsigned a=1;
		int power = 10000;
		a =  a << power;
		std::cout<<2<<"^"<<power<<"-->"<<a<<std::endl;
		
		
		
	} catch(char const* err) {
		std::cout << "The library threw an exception:\n"
			<< err << std::endl;
	}

	return 0;
}

