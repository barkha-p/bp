#include <iostream>
using namespace std;

struct Node{
	int num;
	Node *next,*prev;
	Node(int x=0):num(x){
		prev = next = 0;
	}	
};

class DoublyLL{
	Node *first,*last;	
public:
	DoublyLL():first(0),last(0){}
	void addAtBeg(int);
	void addAtEnd(int);
	void dispFwd();
	void dispRev();
};

int main(){
	DoublyLL one;
	
	for(int cnt=0;cnt<10;cnt+=2){
		one.addAtBeg(100+cnt);
		one.addAtEnd(100+cnt+1);
	}
	one.dispFwd();
	one.dispRev();	
}





void DoublyLL::addAtBeg(int x){
	Node *New= new Node(x);
	if(first==0)
		first = last = New;
	else{
		first->prev = New;
		New->next = first;
		first = New;
	}
}
void DoublyLL::dispFwd(){
	Node *temp = first;
	cout<<"DispFwd: ";
	while(temp){ //temp !=NULL
		cout<<temp->num<<"  ";
		temp=temp->next;
	}
	cout<<endl;
}
void DoublyLL::dispRev(){
	Node *temp = last;
	cout<<"DispRev: ";
	while(temp){ //temp !=NULL
		cout<<temp->num<<"  ";
		temp=temp->prev;
	}
	cout<<endl;
}


void DoublyLL::addAtEnd(int x){
	Node *New= new Node(x);
	if(first==0)
		first = last = New;
	else{
		New->prev = last;
		last->next = New;
		last = New;
	}
}