#include <iostream>
using namespace std;

int main(){
	int *ptr = new int [10];
	for(int cnt=0;cnt<10;cnt++)
		ptr[cnt] = cnt+1;
	
	for(int cnt=0;cnt<10;cnt++)
		cout<<ptr[cnt]<<" ";
	cout<<endl;
	delete[]ptr;
}



