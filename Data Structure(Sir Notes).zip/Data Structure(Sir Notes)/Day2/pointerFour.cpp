#include <iostream>
using namespace std;

int main(){
	int *ptr = new int (10);
	cout<<ptr[0]<<endl;
	cout<<*ptr<<endl;
}

