  #include <iostream>
using namespace std;

class Unique{
	int *ptr;
public:
	Unique(int x=0):ptr(new int(x)){}
	Unique(Unique &rhs){
		ptr = rhs.ptr;//relinquishing
		rhs.ptr=0;// ownwership
	}
	
	Unique& operator=(Unique &rhs){
		int *temp =rhs.ptr ;//copy
		rhs.ptr=ptr;// SWAP
		ptr = temp;//		
		return *this;
	}
	
	friend ostream& operator<<(ostream&, const Unique&);
	
};


int main(){
	Unique a=100;//
	cout<<a<<endl;
	Unique b = a;
	cout<<a<<b<<endl;	
	
}









ostream& operator<<(ostream& out, const Unique& rhs){
	if(rhs.ptr){
	out<<"Address: "<<rhs.ptr;
	out<<"\tVal: "<<*(rhs.ptr);
	}else{
		out<<"Empty";
	}
	
	return out;
}










