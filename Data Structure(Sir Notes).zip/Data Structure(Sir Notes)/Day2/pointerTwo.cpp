#include <iostream>
using namespace std;

int main(){
	int arr[]={1,2,3,4,5,6,7};
	int *ptr = arr+3;
	cout<<ptr[1]<<endl;
	cout<<ptr[-1]<<endl;
}

