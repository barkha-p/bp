#include <iostream>
using namespace std;

int main(){
	int **arr;
	int row,col;
	cout<<"Enter row & col: ";
	cin>>row>>col;
	arr=new int*[row];
	for(int rCnt=0;rCnt<row;rCnt++)
		arr[rCnt] = new int[col];
	
	for(int rCnt=0,num=1;rCnt<row;rCnt++)
		for(int cCnt=0;cCnt<col;cCnt++)
			arr[rCnt][cCnt] = num++;
			
	for(int rCnt=0;rCnt<row;rCnt++){
		for(int cCnt=0;cCnt<col;cCnt++)
			cout<<arr[rCnt][cCnt]<<" ";
		cout<<endl;
	}
		
	for(int rCnt=0;rCnt<row;rCnt++)
			delete[] arr[rCnt];
	delete arr;
			
}



