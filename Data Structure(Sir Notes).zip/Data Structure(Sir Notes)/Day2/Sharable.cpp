 #include <iostream>
using namespace std;

class Sharable{
	int *ptr;
	int *count;
public:
	Sharable(int x=0):ptr(new int(x)),count(new int(1)){}
	
	Sharable(const Sharable &rhs){
		
		ptr = rhs.ptr;
		count = rhs.count;
		(*count)++;
	}
	
	Sharable& operator=(Sharable &rhs){
		ptr = rhs.ptr;
		count = rhs.count;
		(*count)++;
		
		return *this;
	}
	~Sharable(){
		if(--*count)
			ptr = 0;
		else
			delete ptr;
		
	}
	
	friend ostream& operator<<(ostream&, const Sharable&);
	
};


int main(){
	Sharable a=100;//
	cout<<a<<endl;
	Sharable b = a;
	cout<<a<<b<<endl;	
	Sharable c = b;
	cout<<a<<b<<c<<endl;	
	
	Sharable x=100;
	cout<<x<<endl;
}









ostream& operator<<(ostream& out, const Sharable& rhs){
	if(rhs.ptr){
	out<<"Address: "<<rhs.ptr;
	out<<"Count: "<<*(rhs.count);
	out<<"\tVal: "<<*(rhs.ptr);
	}else{
		out<<"Empty"<<endl;
	}
	
	return out;
}










