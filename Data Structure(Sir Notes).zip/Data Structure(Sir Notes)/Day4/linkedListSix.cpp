#include <iostream>
#include <string>
using namespace std;

struct Node{ //self referencial struct
	int num;
	Node *next;	
    Node(int x=0){		
		num=x;
		next=0;
	}
};


void addAtBeg(Node **,int);
void addAtEnd(Node **,int);
void disp(Node *);

int main(){
	Node *arr[100]={0};//head or start
	
	for(int size=0;size<100;size++){
		for(int cnt=0;cnt<10+size;cnt+=2){
			addAtBeg(&arr[size],cnt);	
			addAtEnd(&arr[size],cnt+1);
		}
		disp(arr[size]);		
	}
	
}

void addAtBeg(Node **first,int x){
	Node *New = new Node(x);
	if(*first==0) 
		*first = New;
	else{
		New->next = *first;
		*first = New;
	}
}

void disp(Node *temp){	
	while(temp){
		cout<<temp->num<< " ";		
		temp=temp->next;
	}	
	cout<<endl;
}

void addAtEnd(Node **first,int x){
	Node *New = new Node(x);
	if(*first==0)
		*first = New;
	else{
		Node *temp = *first;
		while(temp->next)
			temp=temp->next;
		temp->next = New;		
	}
}
