#include <iostream>
#include <string>
using namespace std;

struct Node{ //self referencial struct
	int num;
	Node *next;	
    Node(int x=0){		
		num=x;
		next=0;
	}
};


void addAtBeg(Node **,int);
void addAtEnd(Node **,int);
void disp(Node *);

int main(){
	Node *first=0;//head or start
	
	for(int cnt=0;cnt<10;cnt+=2){
		addAtBeg(&first,cnt);	
		addAtEnd(&first,cnt+1);
		disp(first);	
	}
}

void addAtBeg(Node **first,int x){
	Node *New = new Node(x);
	if(*first==0) 
		*first = New;
	else{
		New->next = *first;
		*first = New;
	}
}

void disp(Node *temp){	
	while(temp){
		cout<<temp->num<< " ";		
		temp=temp->next;
	}	
	cout<<endl;
}

void addAtEnd(Node **first,int x){
	Node *New = new Node(x);
	if(*first==0)
		*first = New;
	else{
		Node *temp = *first;
		while(temp->next)
			temp=temp->next;
		temp->next = New;		
	}
}
