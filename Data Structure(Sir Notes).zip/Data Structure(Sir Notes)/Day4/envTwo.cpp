#include <iostream>
#include <cstdlib>

using namespace std;

int main(int argc, char *argv[],char *env[]){
	
	for(int i=0;environ[i];i++)
		cout<<env[i]<<endl;
	
}