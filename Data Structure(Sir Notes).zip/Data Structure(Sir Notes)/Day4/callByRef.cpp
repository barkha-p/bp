#include <iostream>
using namespace std;

void change(int *);//call by address in C++
void change(int &);//call by reference in C++


int main(){
	int var =10;
	cout<<"Var: "<<var<<endl;
	change(&var);//address is passed
	cout<<"Var: "<<var<<endl;
} 

void change(int *ptr){//call by address in C++
	cout<<"Ptr function called"<<endl;
	*ptr += 100;
}
void change(int &ref){
	cout<<"Ref function called"<<endl;
	ref+=100;	
}
