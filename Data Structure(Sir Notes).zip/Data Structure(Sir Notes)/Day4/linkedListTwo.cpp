#include <iostream>
#include <string>
using namespace std;

struct Node{ //self referencial struct
	int num;
	Node *next;	
    Node(int x=0){		
		num=x;
		next=0;
	}
};

Node *first;//head or start
void addAtBeg(int);
void addAtEnd(int);
void disp();

int main(){
	
	addAtBeg(1);
	addAtBeg(2);
	addAtBeg(3);
	disp();	
	addAtEnd(10);
	addAtEnd(20);
	disp();	
}

void addAtBeg(int x){
	Node *New = new Node(x);
	if(first==0) 
		first = New;
	else{
		New->next = first;
		first = New;
	}
}

void disp(){
	Node *temp = first;
	while(temp){
		cout<<temp->num<< " ";		
		temp=temp->next;
	}	
	cout<<endl;
}

void addAtEnd(int x){
	Node *New = new Node(x);
	if(first==0)
		first = New;
	else{
		Node *temp = first;
		while(temp->next)
			temp=temp->next;
		temp->next = New;		
	}
}
