#include <iostream>
#include <string>
using namespace std;

struct Node{ //self referencial struct
	int num;
	string name;
	Node *next;	
    Node(){
		cout<<"Enter num & name:";
		cin>>num>>name;
		next=0;
	}
};

Node *first;//head or start

void addAtBeg();
void addAtEnd();
void disp();

int main(){
	
	addAtBeg();
	addAtBeg();
	addAtBeg();
	disp();	
	addAtEnd();
	addAtEnd();
	disp();	
}

void addAtBeg(){
	Node *New = new Node();
	if(first==0) 
		first = New;
	else{
		New->next = first;
		first = New;
	}
}

void disp(){
	Node *temp = first;
	while(temp){
		cout<<"Num: "<<temp->num;
		cout<<"\tName: "<<temp->name<<endl;
		temp=temp->next;
	}	
}

void addAtEnd(){
	Node *New = new Node();
	if(first==0)
		first = New;
	else{
		Node *temp = first;
		while(temp->next)
			temp=temp->next;
		temp->next = New;		
	}
}
