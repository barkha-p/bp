#include <iostream>
using namespace std;


struct Node {
	int num;
	Node *next;
	Node(int x = 0) :num(x), next(0) {}
	friend ostream& operator<<(ostream&, Node&);
};

class List{
	Node *first;
public:
	List():first(0){ }

	void addAtBeg(int);
	void addAtEnd(int);
	void disp();
};

int main() {
	List one;
	one.addAtBeg(1);
	one.addAtBeg(2);
	one.addAtBeg(3);
	one.disp();
	one.addAtEnd(10);
	one.addAtEnd(20);
	one.disp();
}



ostream& operator<<(ostream &out, Node &rhs) {
	out << rhs.num ;
	return out;
}


void List::addAtBeg(int x){
	Node *New = new Node(x);
	if(first)
		New->next = first;
	first = New;		
}

void List::addAtEnd(int x){
	Node *New = new Node(x);
	if(first==0)
	   first=New;
    else{
		Node *temp = first;
		while(temp->next)
			temp = temp->next;
		temp->next = New;			
	}		
}


void List::disp(){
	Node *temp = first;
	while(temp){
		cout<<*temp<< " ";
		temp = temp->next;
	}
	cout<<endl;
}
	
	