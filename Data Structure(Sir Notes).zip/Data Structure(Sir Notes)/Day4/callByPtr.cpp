#include <iostream>
using namespace std;

void change(char **);

int main(){
	char *str = "Some string here";
	cout<<"Str: "<<str<<endl;
	change(&str);
	cout<<"Str: "<<str<<endl;
}

void change(char **st){
		*st = "NO STRING HERE";
}