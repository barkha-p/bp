import { Component, OnInit } from '@angular/core';
import { DataService } from '../../Services/data.service';

@Component({
  selector: 'app-data',
  templateUrl: './data.component.html',
  styleUrls: ['./data.component.css']
})
export class DataComponent implements OnInit {

  allRecords : any;
  errorMsg : string;
  constructor(private service:DataService) { }

  ngOnInit() {
    this.service.getAllRecords().subscribe((res) => this.allRecords = res);
  }

  onRemove(id:number){
    debugger;
    this.service.remove(id).subscribe((res) => {
      this.errorMsg = res.toString()
        alert(this.errorMsg);
        this.ngOnInit();
    });
  }
}
