import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class DataService {
  
  private url : string ="http://localhost:52347/api/product";
  constructor(private http : HttpClient) {  }

  getAllRecords() : any{
    return this.http.get(this.url);
  }
  remove(id: number) {
    let tempUrl = this.url + "/" + id;
    return this.http.delete(tempUrl);
  }
}
