﻿using SampleWebApi.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using System.Web.Http.Cors;
//All Web API Controllers are classes that are derived from System.Web.Http.ApiController
namespace SampleWebApi.Controllers
{
    [EnableCors("*","*","*","*")]
    public class ProductController : ApiController
    {
        
        ////Get
        //public string GetMessage()
        //{
        //    return "Message sent";
        //}

        //[Route("api/Hate")]
        //public string GetHateMessage()
        //{
        //    return "I hate U";
        //}
        ////Post
        //[HttpPost]
        //public string PostMessage(object msg)
        //{
        //    return msg.ToString() + " sent";
        //}
        ////Get/id
        //public string GetMessage(string id)
        //{
        //    return "Message sent for the id " + id;
        //}\
        [HttpGet]
        public List<ProductTable> AllProducts()
        {
            var com = new CDACTrainingEntities();
            return com.ProductTables.ToList();
        }


        public ProductTable GetProduct(string id)
        {
            var com = new CDACTrainingEntities();
            int pid = int.Parse(id);
            var found = com.ProductTables.FirstOrDefault(p => p.ProductID == pid);
            return found;
        }

        [HttpPost]
        public string AddProduct(ProductTable product)
        {
            try
            {
                var com = new CDACTrainingEntities();
                com.ProductTables.Add(product);
                com.SaveChanges();
                return "Product added";
            }
            catch (Exception ex)
            {
                string msg = ex.Message;
                if ((ex.InnerException != null) || (ex.InnerException.InnerException != null))
                {
                    msg += "\n" + ex.InnerException.Message;
                    msg += "\n" + ex.InnerException.InnerException.Message;
                }
                return msg;
            }
        }

        public string DeleteProduct(string id)
        {
            var com = new CDACTrainingEntities();
            int pid = int.Parse(id);
            var found = com.ProductTables.FirstOrDefault(p => p.ProductID == pid);
            com.ProductTables.Remove(found);
            com.SaveChanges();
            return "Deleted successfully";
        }

        public string PutProductDetails(ProductTable p)
        {
            var com = new CDACTrainingEntities();
            
            var found = com.ProductTables.FirstOrDefault(pr => pr.ProductID == p.ProductID);
            found.ProductName = p.ProductName;
            found.ProductCost = p.ProductCost;
            found.Quantity = p.Quantity;
            com.SaveChanges();
            return "Updated Succesfully";
        }
    }
}
