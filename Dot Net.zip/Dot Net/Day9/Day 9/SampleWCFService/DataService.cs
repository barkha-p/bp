﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
using System.Runtime.Serialization;
namespace SampleWCFService
{
    [ServiceContract]
    public interface IDataService
    {
        [OperationContract]
        List<Employee> GetAllEmployees();
        [OperationContract]
        void AddNewEmployee(Employee emp);
    }
    
    [DataContract]//For Custom types, U must include this attribute
    public class Employee
    {
        [DataMember]
        public int EmpID { get; set; }
        [DataMember]
        public string EmpName { get; set; }
        [DataMember]
        public string EmpAddress { get; set; }
        [DataMember]
        public decimal EmpSalary { get; set; }
    }

    public class DataComponent : IDataService
    {
        public void AddNewEmployee(Employee emp)
        {
            //create the Context object.
            var context = new DataEntities();
            //convert Ur Employee object to EmpTable object...
            var record = new EmpTable
            {
                EmpID = emp.EmpID,
                EmpAddress = emp.EmpAddress,
                EmpName = emp.EmpName,
                EmpSalary = emp.EmpSalary
            };
            //add it to the context collection
            context.EmpTables.Add(record);
            context.SaveChanges();
        }

        public List<Employee> GetAllEmployees()
        {
            var context = new DataEntities();
            var data = context.EmpTables.Select(row => new Employee
            {
                EmpID = row.EmpID,
                EmpName = row.EmpName,
                EmpAddress = row.EmpAddress,
                EmpSalary = row.EmpSalary
            });
            return data.ToList();
        }
    }

}
