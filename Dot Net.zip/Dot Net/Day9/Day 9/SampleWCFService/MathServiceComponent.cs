﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleWCFService
{
    public class MathServiceComponent : IMathService
    {
        public double AddFunc(double v1, double v2)
        {
            return v1 + v2;
        }

        public double SubFunc(double v1, double v2)
        {
            return v1 - v2;
        }
    }
}
