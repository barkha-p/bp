﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ServiceModel;
namespace SampleWCFService
{
    [ServiceContract]//is an optional property...
    public interface IMathService//WCF Service....
    {
        [OperationContract]
        double AddFunc(double v1, double v2);

        double SubFunc(double v1, double v2);


    }
}
