﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Web;
using System.Web.Services;
using System.Configuration;
using System.Diagnostics;

//All data that is used and accessed in Web services should be representable as XML...
/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://tempuri.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
public class WebServiceComponent : System.Web.Services.WebService
{

    public WebServiceComponent()
    {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }
    //Methods that U want to expose thro the service is to be provided with an attribute called Web Method. The class is also provided with an attribute called Webservice. Thd std defined is specified by another attribute called Webservicebinding, which by default will be wsi(web service description) binding provided by Microsoft.  
    [WebMethod]
    public string TestMessage()
    {
        return "Simple Example for Service";
    }
    //Disconnected Data Access....
    [WebMethod]
    public DataSet GetAllEmployees()
    {
        string strCon = ConfigurationManager.ConnectionStrings["myConnection"].ConnectionString;
        SqlDataAdapter ada = new SqlDataAdapter("SELECT * FROM EMPTABLE", strCon);
        DataSet ds = new DataSet("Tables");
        ada.Fill(ds, "ListOfEmployees");//Opens a Closed connection, fills the specified data into a table of the dataset and immediately closes the connection. 
        return ds;
    }

}
