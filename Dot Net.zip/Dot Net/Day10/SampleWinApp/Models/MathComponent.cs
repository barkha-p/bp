﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SampleWinApp.Models
{
    class MathComponent
    {
        public static double AddFunc(double v1, double v2)
        {
            return v1 + v2;
        }
    }
}
