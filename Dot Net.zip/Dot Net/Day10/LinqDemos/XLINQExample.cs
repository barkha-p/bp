﻿using System;//Core APis...
using System.Collections.Generic;//Collections
using System.Linq;//For Basic LINQ...
using System.IO;//For File IO
using System.Xml.Linq;//For XLINQ....

//LINQ to XML....
namespace LinqDemos
{
    class Employee
    {
        public int EmpID { get; set; }
        public string EmpName { get; set; }
        public int EmpSalary { get; set; }
        public string EmpCity { get; set; }
    }
    class XLINQExample
    {
        static List<Employee> getAllEmployees()
        {
            var employees = new List<Employee>();
            using(var reader = new StreamReader("Employees.csv"))
            {
                while (!reader.EndOfStream)
                {
                    var line = reader.ReadLine();
                    var words = line.Split(',');
                    var emp = new Employee
                    {
                        EmpID = int.Parse(words[0]),
                        EmpCity = words[2],
                        EmpName = words[1],
                        EmpSalary = (int)double.Parse(words[3])
                    };
                    employees.Add(emp);
                }
            }
            return employees;
        }

        static void Main(string[] args)
        {
            //var data = getAllEmployees();
            //convertToXml(data);

            //readingXMLFile();
            //insertRecord();
            updateRecord();
        }

        private static void updateRecord()
        {
            var doc = XDocument.Load("Employees.xml");
            var selectedElement = (from element in doc.Descendants("Employee-details")
                                   where element.Element("EmpId").Value == "75"
                                   select element).First();
            selectedElement.Element("EmpName").Value = "Shameer";
            doc.Save("Employees.xml");
        }

        private static void insertRecord()
        {
            var emp = new Employee { EmpID = 501, EmpName = "Phaniraj", EmpCity = "Bangalore", EmpSalary = 65000 };
            //convert employee to XML element...
            var newElement = new XElement("Employee-details", new XElement("EmpId", emp.EmpID),
                                           new XElement("EmpName", emp.EmpName),
                                           new XElement("EmpAddress", emp.EmpCity),
                                           new XElement("EmpSalary", emp.EmpSalary));
            var doc = XDocument.Load("Employees.xml");
            var selectedElement = (from element in doc.Descendants("Employee-details")
                                  where element.Element("EmpId").Value == "7"
                                  select element).First();
            selectedElement.AddAfterSelf(newElement);
            doc.Save("Employees.xml");
        }

        private static void readingXMLFile()
        {
            XDocument doc = XDocument.Load("Employees.xml");
            var query = from element in doc.Descendants("Employee-details")
                        select element;
            foreach(var element in query)
                Console.WriteLine(element.Element("EmpName").Value);
        }

        private static void convertToXml(List<Employee> data)
        {
            var elements = new XElement("AllEmployees", from emp in data
                                                        select new XElement("Employee-details",
                                           new XElement("EmpId", emp.EmpID),
                                           new XElement("EmpName", emp.EmpName),
                                           new XElement("EmpAddress", emp.EmpCity),
                                           new XElement("EmpSalary", emp.EmpSalary)));
            elements.Save("Employees.xml");


        }
    }
}
