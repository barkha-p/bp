﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
//Language Integrated Queries introduced in .NET 3.0 was created to perform Language based queries on collections. Later extended to XML and SQL server database. 
//To support LINQ, C# was added with new keywords like var, from, where, order by, group by and many more to accomodate the Querying capability on Collections. 
//New features came up in .NET 3.5 like Anonymous methods, Automatic Properties, Anonymous Types, Extension Methods, Lambda Expressions. The most significant change in .NET happened in the v3.0 and immediately followed by v3.5 in the year of 2008-09. The complete support with the IDE was provided in .NET 4.0 of VS 2010.

namespace LinqDemos
{
    static class CustomHelpers
    {
        /*Rules:
         * Extension methods are extended to a type that is passed as the first arg of the method. 
         * Extension method is extended to the object of the class, not for the class itself..
         */
        public static int NoOfWords(this string sentence)
        {
            var words = sentence.Split(',', ';', ':',' ');
            return words.Length;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            //usingVarKeyword();
            //anonymousTypes();
            //extensionMethods();
            //firstLinqExample();
        }


        private static void firstLinqExample()
        {
            
            var fruits = new string[]
            {
                "Apple","Mango","Orange","Grapes","PineApple"
            };
            var copy = from fruit in fruits
                       where fruit.ToLower().Contains("a")
                       select fruit;//select * from fruits...
            //Statement starts with a from clause and ends with a select clause. b/w the from and the select U could optionally have where, group, order by, join, and many more...
            //LINQ can be applied on collections only. The in keyword looks for a collection object..
            foreach(var c in copy)
                Console.WriteLine(c);
        }

        private static void extensionMethods()
        {
            string data = "Strongly Typed Views: A View is typically associated with a model type.  This is called as Strongly typed View. A View can have only one Model type. While creating the View, U could mention the Model type that U want to associate with the View. When a View is associated with any model type, then its called as STRONGLY TYPED VIEW.";
            Console.WriteLine("The no of words in this sentense is".NoOfWords()); 
        }
        
        private static void anonymousTypes()
        {
            //EmpId, FirstName, MiddleName, LastName, Location, Address1, Address2, City , PinCode, State, Country, Qualification, University, College, 
            //If U want to create an object without a class declaration U can go for anonymous types....
            var employee = new { EmpID = 123, EmpName = "Phaniraj", EmpAddress = "Bangalore" };//Based on design pattern called Data Carriers. These objects contain only properties to hold the data in the Application. 
            Console.WriteLine(employee.EmpName + " is from " + employee.EmpAddress);

        }

        private static void usingVarKeyword()
        {
            /*
             * var is implicit typed local variables.
             * var cannot be used as return type of a method or a property
             * var cannot be used as parameter of a method.
             * var cannot be used as fields of a class. 
             * var cannot be declared in one statement and assigned in another statement.
             * Once a var is associated with a value, it implicitly holds the type info of that value and will follow all the rules of that type. 
             * var is mostly used for convinience in declaring and consuming local scoped variables
             */
            var element = 123;
            var variable = 123;
            variable += int.Parse("123");
            var stringData = "Strings";
            var words = new Dictionary<string, string>();
            words["Apple"] = "Nice Fruit with lot of healthy components";
            words["Mango"] = "King of Fruits";
            words["PineApple"] = " Cool Fruit with juicy stuff";
            foreach(var pair in words)
            {
                Console.WriteLine($"Key:{pair.Key}\nValue{pair.Value}");
            }
        }
    }
}
 