﻿using System;//Core APIs
using System.Collections.Generic;//Collections
using System.Linq;//Linq Operations
using System.IO;//File access

//LINQ is done on IEnumerable objects which is forward only and read only. LINQ is not designed for Insertion,Deletion and Updation. Collections have their own functions to add, remove and update. 
//LINQ is extended to XML(XLINQ) and SQL(LINQ to SQL Classes) where U could have methods to insert, delete and update along with the regular LINQ Expressions. 

namespace LinqDemos
{
    class Car
    {
        public int CarNo { get; set; }
        public string Brand { get; set; }
        public string Model { get; set; }
        public double Price { get; set; }
        public override string ToString()
        {
            return $"{Brand}-{Model}";
        }
    }
    class LinqExamples
    {
        const string filename = "Cars.csv";
        static List<Car> AllCars
        {
            get
            {
                return getCars();
            }
        }

        private static List<Car> getCars()
        {
            List<Car> all = new List<Car>();
            var reader = new StreamReader(filename);
            while (!reader.EndOfStream)
            {
                var line = reader.ReadLine();
                var words = line.Split(',');
                for (int i = 0; i < words.Length; i++)
                {
                    Car car = new Car();
                    car.CarNo = int.Parse(words[0]);
                    car.Brand = words[1];
                    car.Model = words[2];
                    car.Price = double.Parse(words[3]);
                    all.Add(car);
                } 
            }
            reader.Close();
            return all;
        }

        static void Main(string[] args)
        {
            //allCarsExample();
            //whereClause();
            //groupByClause();
            //orderByClause();
        }

        private static void orderByClause()
        {
            var cars = AllCars;
            var sorted = from car in cars
                         orderby car.Brand descending
                         select car;
            foreach(var car in sorted)
                Console.WriteLine(car);
        }

        private static void groupByClause()
        {
            var cars = AllCars;
            var groups = from car in cars
                         group car by car.Brand into gr
                         select gr;
            //U get a collection of groups where each group is a collection of cars...
            foreach(var group in groups)
            {
                Console.WriteLine("Cars of the brand: " + group.Key);
                foreach(var car in group)
                {
                    Console.WriteLine(car.Model);
                }
                Console.WriteLine("-----------------------------------------------");
            }
        }

        private static void whereClause()
        {
            var cars = AllCars;
            Console.WriteLine("Enter the Car brand to search");
            var carToLook = Console.ReadLine();
            var subCars = from car in cars
                          where car.Brand == carToLook
                          select car;
            foreach(var car in subCars)
                Console.WriteLine(car);
        }

        private static void allCarsExample()
        {
            var cars = AllCars;
            var carList = from car in cars
                          select car;//select * from cars....
            //For every LINQ expression, a Collection will be returned....
            foreach (var car in carList)
                Console.WriteLine(car);
            //The LINQ query will be executed only when U iterate thro the foreach statement on the result of the Query...
        }
    }
}
