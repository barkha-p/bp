﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
namespace LinqDemos
{
    class LinqSqlDemo
    {
        static void Main(string[] args)
        {
            //bulkInsertionExample();
            //insertSingleRecord();
            bulkDeletionExample();
        }

        private static void bulkDeletionExample()
        {
            var context = new EmployeeDataContext();
            var records = from emp in context.EmpTables
                          where emp.EmpID > 50
                          select emp;
            context.EmpTables.DeleteAllOnSubmit(records.ToList());
            context.SubmitChanges();
        }

        private static void insertSingleRecord()
        {
            //create the object to add
            var emp = new EmpTable { EmpID = 502, EmpName="Suraj", EmpAddress="Goa", EmpSalary= 55000 };
            //create the data context
            var context = new EmployeeDataContext();
            //insert the object into the collection
            context.EmpTables.InsertOnSubmit(emp);
            //submit the changes...
            context.SubmitChanges();//Commit....
        }

        private static void bulkInsertionExample()
        {
            var doc = XDocument.Load("Employees.xml");
            var data = from element in doc.Descendants("Employee-details")
                       select new EmpTable
                       {
                           EmpID = int.Parse(element.Element("EmpId").Value),
                           EmpName = element.Element("EmpName").Value,
                           EmpAddress = element.Element("EmpAddress").Value,
                           EmpSalary = int.Parse(element.Element("EmpSalary").Value)
                       };
            //create the contextobj
            var context = new EmployeeDataContext();
            context.EmpTables.InsertAllOnSubmit(data.ToList());
            context.SubmitChanges();
        }
    }
}
