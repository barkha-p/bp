﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace LinqDemos
{
    delegate void RaiseMe();

    class Titan//created yesterday
    {
        public event RaiseMe CallMe;//Reference of a Delegate....
        public DateTime AlarmTime { get; private set; }
        public Titan(DateTime alarmTime)
        {
            AlarmTime = alarmTime;
        }
        public void Display()
        {
            while (true)
            {
                if(AlarmTime.ToShortTimeString() == DateTime.Now.ToShortTimeString())
                {
                    if(CallMe!= null)
                        CallMe();
                }
                
                Console.WriteLine(DateTime.Now.ToLongTimeString());
                Thread.Sleep(1000);
                Console.Clear();
            }
        }
    }
    class AlarmClockExample
    {
        static void ThreadFunc()
        {
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("Thead Beep#" + i);
                Thread.Sleep(1000);
                
            }
        }
        static void Main(string[] args)
        {
            //Console.ForegroundColor = ConsoleColor.Red;
            //Titan wallClock = new Titan(DateTime.Now.AddSeconds(20));
            ////wallClock.AlarmTime = DateTime.Now.AddSeconds(15);
            //wallClock.CallMe += WallClock_CallMe;
            //wallClock.Display();

            //Thread th = new Thread(ThreadFunc);
            //th.IsBackground = true;
            //th.Start();
            //for (int i = 0; i < 5; i++)
            //{
            //    if (i == 3)
            //    {
            //        if(th.ThreadState == ThreadState.Running)
            //            th.Suspend();
            //    }
            //    Console.WriteLine("Main Program");
            //    Thread.Sleep(2000);
            //}
            //if (th.ThreadState == ThreadState.Suspended)
            //    th.Resume();

            ThreadPool.QueueUserWorkItem((obj) =>
            {
                ThreadFunc();
            });
            for (int i = 0; i < 100; i++)
            {
                Console.WriteLine("Main is doning some job");
                Thread.Sleep(1000);
            }
        }

        private static void WallClock_CallMe()
        {
            onSomeWork();
        }

        static void onSomeWork()
        {
            Console.WriteLine("Time to go and practise in the Lab...");
        }
    }
}
