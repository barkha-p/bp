//helper functions for DOM manipulations and reading...
function $(id){
	return document.getElementById(id);
}