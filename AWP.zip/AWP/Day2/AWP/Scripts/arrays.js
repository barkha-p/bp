var elements = ["Apple","Mango","Orange"];//array initialization syntax...
//var elements = [];
function getArray(){
	return elements;
}

//push method
function addItem(item){
	elements.push(item);
}
//splice method
function remove(item){
	var index = elements.indexOf(item);
	if(index < 0)
	{
		alert("Element not found");
		return;
	}
	elements.splice(index, 1);
	
}
//filter method
function findAll(item){
	var foundElements = elements.filter(function(e){
		return e.includes(item);//returns boolean(true means found item).
	})
	return foundElements;
}

//find method
function findItem(item){
	return elements.find(function(e){
		return e == item;
	})
}