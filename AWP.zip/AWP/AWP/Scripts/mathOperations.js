function addFunc(first, second){
	return first + second;
}
function subFunc(first, second){
	return first - second;
}
function mulFunc(first, second){
	return first * second;
}
function divFunc(first, second){
	return first / second;
}

function process(first, second, operand){
	var res = 0.0;//initialize the data to a number...
	switch(operand){
		case "+":
			res = addFunc(first, second);
			break;
		case "-":
			res = subFunc(first, second);
			break;
		case "X":
			res = mulFunc(first, second);
			break;
		case "/":
			res = divFunc(first, second);
			break;
	}
	return res;
}

function square(first){
	return first * first;
}

function  squareRoot(first){
	return Math.sqrt(first);
}