//helper functions for DOM manipulations and reading...
function $(id){
	return document.getElementById(id);
}
function $click(id, func){
	$(id).addEventListener('click',func);
}

//helper function is providing a common click event procedure for all the elements matching to the classname....
function $mapClick(classname, func){
	var elements = document.getElementsByClassName(classname);//collection
	for(let i =0; i < elements.length;i++){
		elements[i].addEventListener('click', func);
	}	
}