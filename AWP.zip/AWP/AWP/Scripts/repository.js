var book = function(id, title, price, author){
	this.bookId = id;
	this.title = title;
	this.cost = price;
	this.author = author;
}//A Class prototype for a book....

var bookStore = function(){
	var data = [
		new book(111, 'Professional C#', 650, 'James'),
		new book(112, 'Inside COM', 450, 'Dale Rogerson'),
		new book(113, '2 States', 250, 'Chetan Bhagat'),
		new book(114, 'The God Father', 250, 'Mario Puzo')
	];//blank array in JS....

	this.addBook = function(bk){
		data.push(bk);
		alert("The Book is added successfully")
	}

	this.findBook = function(id){
		var bk = data.find(function(b){
				return b.bookId == id;
			});
		if(bk == undefined)
			throw "Book not found"; // Exception raised on a condition....
		return bk;
	}

	this.deleteBook = function(id){
		for(let i =0; i < data.length;i++){
			if(data[i].bookId == id){
				data.splice(i, 1);
				return;//exits the function.....
			}
		}
		throw "Book with ID " + id +" not found to delete";	
	}

	this.updateDetails = function(bk){
		for(let i =0; i < data.length;i++){
			if(data[i].bookId == bk.bookId){
				//replace the data in that index location...
				data[i].title = bk.title
				data[i].cost = bk.cost;
				data[i].author = bk.author
				alert("Book details are updated")
				return;//exits the function.....
			}
		}//at this point, there is no book in our collection to update
		throw "there is no book in our collection to update";
	}

	this.getAllBooks = function(){
		return data;
	}
}

