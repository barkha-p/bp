//objects in javascript are represented by {}. 
var emp = {};
emp.empid = 123;
emp.empName ="Phaniraj"
// console.log(typeof(emp));
// console.log(emp.empName);

//every function is an object...
var employee = function(id, name, address){
	this.empId = id;
	this.empName = name;
	this.empAddress = address;
	this.printValues = function(){
		console.log(`The name is ${this.empName} from ${this.empAddress}`)//ES6 syntax
	}//objects can have both data properties as well as functions....
}//prototype....

function addFunc(first, second){
	console.log(first + second);
}


/*var e1 = new employee(123, 'Phaniraj','Bangalore');
//console.log(e1);
e1.printValues();*/

/////////Another syntax of object creation/////////////
var customerInfo = function(){
	var cstId =0;
	var cstName = "";
	setDetails = function(id, name){
		cstId = id;
		cstName = name;
	}

	getDetails = function(){
		console.log(`The Name: ${cstName}\nThe ID: ${cstId}`);
	}
	return{
		set : setDetails,
		get : getDetails
	}
}

var empObj = new customerInfo();
empObj.set(123,'TestName');
empObj.get();