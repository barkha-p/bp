var elements = ["Apple","Mango","Orange"];//array initialization syntax...

function getArray(){
	return elements;
}

//push method
function addItem(item){
	elements.push(item);//Adds a new item to the bottom of the List..
}
//splice method
function remove(item){
	var index = elements.indexOf(item);//get the index of the item to remove..
	elements.splice(index, 1);//index is from where the items are removed and 1 is the no of items to remove
	//PS:splice is also used to replace an element, the 3rd arg is an optional arg that contains the item to replace. 
}
//filter method
function findAll(item){
	var foundElements = elements.filter(function(e){
		return e.includes(item);//returns boolean(true means found item).
	})
	return foundElements;
}

//find method
function findItem(item){
	return elements.find(function(e){
		return e == item;
	})
}