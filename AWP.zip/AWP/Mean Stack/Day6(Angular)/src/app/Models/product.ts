export class Product {
    public productID : number;
    public name :string;
    price : number;
    category : string;
    avatar : string;
    
    constructor(id:number, name :string, cost :number, cat : string, av : string) {
        this.name = name;
        this.price = cost;
        this.productID = id;
        this.category = cat;
        this.avatar = av;
    }
}
