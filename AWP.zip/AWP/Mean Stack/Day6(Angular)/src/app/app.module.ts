import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";

import { AppComponent } from './app.component';
import { CalcComponent } from './Components/calc/calc.component';
import { ProductListComponent } from './Components/product-list/product-list.component';
import { ItemFilterPipe } from './Pipes/item-filter.pipe';

@NgModule({
  declarations: [
    AppComponent,
    CalcComponent,
    ProductListComponent,
    ItemFilterPipe
  ],
  imports: [
    BrowserModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
