import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-calc',
  templateUrl: './calc.component.html',
  styleUrls: ['./calc.component.css']
})
export class CalcComponent implements OnInit {
  //Data to bind to the user interface. This component will have functions that will be invoked by the HTML elements as events....
  constructor() { }
  firstValue : number = 5.4;//float value.....
  secondValue : number = 4.6;
  operand : string = "-";
  result = this.firstValue + this.secondValue;
  ngOnInit() {
  }

  //void function....
  process(){
    switch(this.operand){
      case "+":
        this.result = this.firstValue + this.secondValue;
        break;
      case "-":
        this.result = this.firstValue - this.secondValue;
        break;
      case "X":
      this.result = this.firstValue * this.secondValue;
      break;
      case "/":
      this.result = this.firstValue / this.secondValue;
      break;
    }  
  }
}
