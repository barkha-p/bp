import { Pipe, PipeTransform } from '@angular/core';
import { Product } from '../Models/product';

@Pipe({
  name: 'itemFilter'
})
//Pipe is a way to tranform the content U intend to show to the user.
export class ItemFilterPipe implements PipeTransform {
//Angular gives builtin filters, U could create UR own filter by implementing PipeTransform interface which has function transform
  transform(inputs: Product[], criteria?: string): Product[] {
    if(criteria == ""){
      return inputs;
    }else{
      return inputs.filter( p => p.name.includes(criteria));
    }
  }

}
