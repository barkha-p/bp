import { ItemFilterPipe } from './item-filter.pipe';

describe('ItemFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new ItemFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
