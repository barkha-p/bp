import { Component, OnInit } from '@angular/core';
import { RestClientService } from 'src/app/Services/rest-client.service';

@Component({
  selector: 'app-rest-client',
  templateUrl: './rest-client.component.html',
  styleUrls: ['./rest-client.component.css']
})
export class RestClientComponent implements OnInit {
  //We need our service to be injected here...
  constructor(private myService : RestClientService) { }
  public allEmployees : any[] = [];
  public selectedEmp : any;
  public newId: number;
  public newName : string;
  public newAddress : string;
  public newSalary : string;
  //display the employees
  ngOnInit() {
    this.allEmployees = this.myService.getAll();
  }

  findEmployee(id: number){
    //The Http service returns an Observable<T> object that is used to provide a callback function to set values to the members of the component
    this.myService.find(id).subscribe(arg => {
      this.selectedEmp = arg[0];   
    })
  }

  updateRecord(){
    this.myService.update(this.selectedEmp).subscribe((arg)=>{
      
    })
    alert("Employee updated");
  }

  addRecord(){
     let rec = {empID: this.newId, empName : this.newName, empAddress : this.newAddress, empSalary : this.newSalary};
     this.myService.insert(rec).subscribe(arg=>{
       alert(arg);
     })
  }

}
