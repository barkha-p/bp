import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { Product } from 'src/app/Models/product';

@Component({
  selector: 'app-new-product',
  templateUrl: './new-product.component.html',
  styleUrls: ['./new-product.component.css']
})
export class NewProductComponent implements OnInit {
  @Output() onNewProduct : EventEmitter<Product> = new EventEmitter<Product>();
  newID : number =0;
  newName : string ="";
  newCost : number =0.0;
  newImg  : string ="";
  constructor() { }

  ngOnInit() {
  }

  onSubmit(){
    let product = new Product(this.newID, this.newName, this.newCost, "Fruits", this.newImg);
    this.onNewProduct.emit(product);
  }

}
