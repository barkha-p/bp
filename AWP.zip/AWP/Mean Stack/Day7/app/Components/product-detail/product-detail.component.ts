import { Component, OnInit, Input } from '@angular/core';
import { Product } from 'src/app/Models/product';

@Component({
  selector: 'app-product-detail',
  templateUrl: './product-detail.component.html',
  styleUrls: ['./product-detail.component.css']
})
export class ProductDetailComponent implements OnInit {
  @Input()//This injects as input to this Component
  currentProduct : Product;
  constructor() { }

  ngOnInit() {
    //this.currentProduct = new Product(111, "Apple",190, "Fruits", "assets/Images/apple.jpg");
  }

}
