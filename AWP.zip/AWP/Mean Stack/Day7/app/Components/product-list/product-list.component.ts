import { Component, OnInit } from '@angular/core';
import { Product } from 'src/app/Models/product';

@Component({
  selector: 'app-product-list',
  templateUrl: './product-list.component.html',
  styleUrls: ['./product-list.component.css']
})

//OnInit is a interface that a component implements thro a function called ngOnInit where initialization required for UR data will be done...
//Alternatively U could initialize it even in the constructor...
export class ProductListComponent implements OnInit {
  public fruitSearch:string ="";
  products : Product [] =[];//blank array...

  //Array of products: They are hard-coded
  //Display the list of products in the UI..
  //Planning to filter based on search condition...
  constructor() { }

  ngOnInit() {
    this.products.push(new Product(111, "Apples", 190, "Fruits", "assets/Images/apple.jpg"));
    this.products.push(new Product(112, "Mangos", 90, "Fruits", '/assets/Images/mango.jpg'));
    this.products.push(new Product(113, "gauva", 19, "Fruits", 'assets/Images/gauva.jpg'));
    this.products.push(new Product(114, "blackGrape", 190, "Fruits", "assets/Images/blackGrape.jpg"));
    this.products.push(new Product(115, "greenGrapes", 90, "Fruits", '/assets/Images/greenGrapes.jpg'));
    this.products.push(new Product(116, "kiwi", 19, "Fruits", 'assets/Images/kiwi.jpg'));
    this.products.push(new Product(117, "orange", 190, "Fruits", "assets/Images/orange.jpg"));
    this.products.push(new Product(118, "pine-apple", 90, "Fruits", '/assets/Images/papple.jpg'));
    this.products.push(new Product(119, "Strawberries", 19, "Fruits", 'assets/Images/strawberries.jpg'));
  }

  addItem(obj : Product){
    this.products.push(obj);
    alert("Product added");
  }
}
