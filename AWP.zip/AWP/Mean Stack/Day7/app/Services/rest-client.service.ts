import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'//new in Ang7 
})
export class RestClientService {
 private url : string = 'http://localhost:1234/';
  constructor(private http: HttpClient) { }

  getAll() : any{
    return this.http.get(this.url);
  }

  find(id:number): any{
    let tempUrl = this.url + id;
    console.log(tempUrl);
    return this.http.get(tempUrl);
  }

  insert(emp: any){
    return this.http.post(this.url, emp);
  }

  delete(no : number): any{
    let tempUrl = this.url +'/' + no;
    return this.http.delete(tempUrl);
  }

  update(emp: any){
    return this.http.put(this.url, emp);
  }
}
