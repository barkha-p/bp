import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { RouterModule, Route } from "@angular/router";

import { AppComponent } from './app.component';
import { CalcComponent } from './Components/calc/calc.component';
import { ProductListComponent } from './Components/product-list/product-list.component';
import { ItemFilterPipe } from './Pipes/item-filter.pipe';
import { ProductDetailComponent } from './Components/product-detail/product-detail.component';
import { NewProductComponent } from './Components/new-product/new-product.component';
import { RestClientComponent } from './Components/rest-client/rest-client.component';
import { RestClientService } from './Services/rest-client.service';
const routes : Route[] = [
  {"path":'calc', component : CalcComponent},
  {"path":'product', component : ProductListComponent},
  {"path" :'service', component : RestClientComponent}
];

@NgModule({
  declarations: [
    AppComponent,
    CalcComponent,
    ProductListComponent,
    ItemFilterPipe,
    ProductDetailComponent,
    NewProductComponent,
    RestClientComponent
  ],
  imports: [
    BrowserModule,
    FormsModule,
    HttpClientModule,
    RouterModule.forRoot(routes)
  ],
  providers: [ RestClientService],
  bootstrap: [AppComponent]
})
export class AppModule { }
