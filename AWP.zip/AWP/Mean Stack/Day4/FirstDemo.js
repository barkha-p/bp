function addFunc(first, second) {
	return first + second;
}

function testcode(){
	return "Welcome123";
}

console.log(testcode());
console.log(addFunc(123, 234));
console.log("Apple testing in File")
/*
var http = require("http");
http.createServer((req, res)=>{
	res.end("Hello world");
}).listen(1234);
*/