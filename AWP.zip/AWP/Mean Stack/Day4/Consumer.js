/*******Using Anonymous Modules**********
var cart = require('./CustomModules');

cart.addProduct({"id": 123, "name":"Max 2", "price": 56000});
cart.addProduct({"id": 124, "name":"Note 2", "price": 6000});
cart.addProduct({"id": 125, "name":"Mi TV", "price": 56000});
cart.addProduct({"id": 126, "name":"Mi A2", "price": 5000});

var items = cart.getAllItems();
items.forEach((v, i)=>console.log(v.name));
console.log("")
cart.remove(125);
items = cart.getAllItems();
items.forEach((v, i)=>console.log(v.name));*/

var multiComponentModule = require('./CustomModules');
/*console.log(multiComponentModule);
console.log(multiComponentModule.developer);
console.log(multiComponentModule.date);*/

var amazon = require('./CustomModules').shoppingCart;
amazon.addProduct({"title":123})
amazon.addProduct({"title":123})
amazon.addProduct({"bookname" :"Nodejs Examples"});
amazon.addProduct({"title":123})
amazon.addProduct({"title":123})
amazon.addProduct({"Title":123})


var items = amazon.getAllItems();
for (var i = items.length - 1; i >= 0; i--) {
	console.log(items[i]);
}
/*
var cart = multiComponentModule.shoppingCart;
cart.addProduct({"id": 123, "name":"Max 2", "price": 56000});
cart.addProduct({"id": 124, "name":"Note 2", "price": 6000});
cart.addProduct({"id": 125, "name":"Mi TV", "price": 56000});
cart.addProduct({"id": 126, "name":"Mi A2", "price": 5000});

var items = cart.getAllItems();
items.forEach((v, i)=>console.log(v.name));
Node
*/

//alert("Test123"); U have console.log but no function to take inputs from the user...