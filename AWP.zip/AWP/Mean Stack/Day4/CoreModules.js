var fs = require('fs');
/*var contents = fs.readFileSync("Notes.txt",'utf8');
console.log(contents);*/

//U could read a file asynchronously also....

/*fs.readFile("Notes.txt", 'utf8', (err, data)=>{
	if(err) console.log(err);
	console.log(data);//data is the content of the file that U wish to read...
})

console.log("End of the program");
*************Writing to a File***************** */
var fname ="SampleText.txt";
//fs.writeFile(fname, "Some More Text to write in the file", (Err)=>{ if(Err) console.log(Err)});

fs.appendFile(fname, "\nAdding one more line of code", (err)=> {if(err) console.log(err)});