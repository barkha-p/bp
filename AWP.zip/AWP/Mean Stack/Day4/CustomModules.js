//CustomModules.js
/*var data = (function(){
	console.log("testing123");

	this.testFunc = function(){
		console.log("testFunc");
	}
})();
data.testFunc();
console.log(data);
*/
//In JS, if U want a set of operations to be exported to external files, U should use module.exports....
/*****************Anonymous Modules***********************
module.exports = (function(){
	var cart = [];//array in JS....

	function addItem(item){
		cart.push(item)
	};

	function getAll(){
		return cart;
	}

	function remove(id){
		var item = cart.find((i)=>i.id == id);
		var index = cart.indexOf(item);
		cart.splice(index, 1);
	}

	return {
		addProduct : addItem,
		getAllItems : getAll,
		remove : remove
	};
})();

**************Named Modules***********************/
//module.exports == exports.....
exports.shoppingCart = (function(){
	var cart = [];//array in JS....

	function addItem(item){
		cart.push(item)
	};

	function getAll(){
		return cart;
	}

	function remove(id){
		var item = cart.find((i)=>i.id == id);
		var index = cart.indexOf(item);
		cart.splice(index, 1);
	}

	return {
		addProduct : addItem,
		getAllItems : getAll,
		remove : remove
	};
})();

exports.title ="Nodejs Program";
exports.developer ="Phaniraj B.N.";
exports.date = new Date();







