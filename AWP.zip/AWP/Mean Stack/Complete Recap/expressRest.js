//npm install express;
var app = require('express')();

app.use((req, res, next)=>{
    res.header('Access-Control-Allow-Origin', '*');
	res.header('Access-Control-Allow-Methods', 'GET, PUT, POST, DELETE');
	res.header('Access-Control-Allow-Headers', '*');
    next();
})
app.get('/:id', (rq, rs)=>{
    var sql = require('mysql');
    var config ={
        server : 'localhost',
        user:'root',
        password:'',
        database:'cdactraining'
    };
    var id= rq.params.id;
    var con = sql.createConnection(config);
    con.query('select * from marks where student_id=' + id, (err, results)=>{
        rs.send(results);//results is array, we get the 1st element of the array
    });
})

app.get('/Student/:id', (rq, res)=>{
    var sql = require('mysql');
    var config ={
        server : 'localhost',
        user:'root',
        password:'',
        database:'cdactraining'
    };
    var id= rq.params.id;
    var con = sql.createConnection(config);
    con.query('select * from student where id=' + id, (err, results)=>{
        res.send(results);//results is array, we get the 1st element of the array
    });
})

app.listen(1234, function(){
    console.log("Server is ready at 1234");
})