<?php 
	function makeConnection(){
		$server = 'localhost';
		$username ='root';
		$pwd = "";
		$dbName = "student";

		$con = new mysqli($server, $username, $pwd, $dbName);
		return $con;
	}

	function insertStudent($name, $address, $contact){
		$con = makeConnection();
		$query = sprintf("insert into studentreg(Name, Address, Contact) values('%s','%s','%s')",$Name, $Address, $Contact);
		$con->query($query);
	}

	function insertMarks($id, $m1,$m2,$m3){
		$con = makeConnection();
		$query = sprintf("insert into marks(stdid,maths,science,social) values('%s','%s','%s','%s')",$stdID,$m1,$m2,$m3);
		$con->query($query);
	}
 ?>