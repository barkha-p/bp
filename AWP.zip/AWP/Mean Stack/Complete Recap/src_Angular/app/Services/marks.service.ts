import { Injectable } from '@angular/core';
import { HttpClient } from "@angular/common/http";
@Injectable({
  providedIn: 'root'
})
export class MarksService {
  url : string ="http://localhost:1234/"
  score : any;
  constructor(private http : HttpClient) { 

  }
  //API called after the user enters the ID and calls this function...
  getScore(id: number): any{
    let tempUrl = this.url + id;
    return this.http.get(tempUrl);
  }

  getStudent(id:number){
    let tempUrl = this.url + 'Student/' + id;
    return this.http.get(tempUrl);
  }
}
