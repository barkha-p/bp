import { Component, OnInit } from '@angular/core';
import { MarksService } from 'src/app/Services/marks.service';

@Component({
  selector: 'app-marks',
  templateUrl: './marks.component.html',
  styleUrls: ['./marks.component.css']
})
export class MarksComponent implements OnInit {
  score : any;
  studentDetails : any;
  studentID : number = 0;
  constructor(private service : MarksService) { }

  ngOnInit() {

  }

  onSubmit(){
    if(this.studentID == 0){
      alert("Student ID is not a valid value");
      return;
    }
    this.service.getScore(this.studentID).subscribe((res)=>{
      this.score = res[0];
    });

    this.service.getStudent(this.studentID).subscribe((res)=>{
      this.studentDetails = res[0];
    })
  }
}
