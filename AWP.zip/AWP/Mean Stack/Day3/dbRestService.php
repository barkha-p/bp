<?php 
#Program to create a REST service based on data from database...
	function getConnection(){
		$server ='localhost';
		$db = 'cdactraining';
		$user ="root";
		$pwd ="";

		$con = new mysqli($server, $user, $pwd, $db);
		if(!$con)
			echo "Connection Failed";
		else
			return $con;
	}

	function getAll(){
		$con = getConnection();
		if(!$con)
			return;
		$query = "select * from emptable";
		$results = $con->query($query);
		$records = array();
		while($row = $results->fetch_assoc()){
			$records [] = $row;
		}
		echo json_encode($records);
	}

	function find($id){
		$con = getConnection();
		$query = "SELECT * FROM EMPTABLE WHERE EMPID = " . $id;
		$result = $con->query($query);
		while ($row = $result->fetch_assoc()) {
			echo json_encode($row);
		}
	}

	function insertRecord(){
		$id = $_POST["id"];
		$name = $_POST["name"];
		$address = $_POST["address"];
		$salary = $_POST["salary"];
		$con = getConnection();
		$query = sprintf("insert into emptable values('%s','%s','%s','%s')", $id, $name, $address, $salary);
		$con->query($query);
		echo "inserted successfully";
	}

	function update(){
		$id = $_POST["id"];
		$name = $_POST["name"];
		$address = $_POST["address"];
		$salary = $_POST["salary"];
		$con = getConnection();
		$query = sprintf("update emptable set empname ='%s', empaddress = '%s', empsalary = '%s' where empid = '%s')", $name, $address, $salary, $id);
		$con->query($query);
		echo "updated successfully";	
	}

	function deleteRecord(){
		echo "do it urself...";
	}

	$method = $_SERVER["REQUEST_METHOD"];
	switch ($method) {
		case 'GET': //extract the data from the service
			if(isset($_GET["id"])){
				$id = intval($_GET["id"]);
				find($id);
			}else
				getAll();
			break;
		case "POST"://To add new data into the service...
			insertRecord();
			break;
		case "PUT": //To update data into the service...
			updateRecord();
			break;
		case "DELETE"://To delete the data from the service....
			deleteRecord();
			break;
		default:
			echo "Not implemented";
			break;
	}
 ?>