//httpRestExample.js
var http = require('http');
//rest services expose the data thro JSON/XML. 
var jsondata = require('./data.json');

http.createServer((req, res)=>{
	switch(req.method){
		case "GET":
			res.end(JSON.stringify(jsondata));
			break;
		case "POST":
			req.on('data', (body)=>{
				console.log(body.toString());
				res.end("data recieved");
			})
		break;
		default:
			res.end("invalid method");
			break;		
	}
}).listen(1234);
