var http = require('http');
var fs = require('fs');
var path = require('path');

var dir = __dirname;

function errorPage(res) {
	res.writeHead(200, {'Content-type' : 'text/html'});
	var content ='<h1>OOPS! Something wrong happened</h1>';
	content += '<p>Site under maintainance</p>';
	content += '<p>Will Get back to you</p>';
	content += '<hr/><p>&copy;Phaniraj B.N.' + new Date().getFullYear();
	res.end(content);
}


http.createServer((req, res)=>{
	var url = req.url;
	console.log(url)
	if(url == '\favicon.ico')
		return;
	var filename = path.join(dir, req.url);
	switch(req.url){
		case '/':
			res.write("<h1>Home Page</h1>");
			break;
		case "/Courses":
			res.write("<h1>List of Coures with us</h1>");
			break;
		default:
			var fname = path.join(dir, req.url + '.html');
			if(fs.existsSync(fname)){
				fs.createReadStream(fname).pipe(res);
				return;
			}			
	}
	res.end('<hr/>&copy;Phaniraj B.N.' + new Date().getFullYear());
	//Another way to read a file in Nodejs:
	//Stream is an event that contains an action called data which is triggered when the stream is filled with the data....	
	//fs.createReadStream(filename, 'utf8').pipe(res); //pipe method will stream the output to the response object which displays the data for us.... pipe closes the response after the data is piped to the response. There is no need to call response.end();
}).listen(1234);
