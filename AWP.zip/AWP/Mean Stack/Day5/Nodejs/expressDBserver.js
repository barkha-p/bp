//This example connects to mysql database of our machine and displays the data to the user...
var app = require('express')();
//app.set('views', 'jade');
app.set('view engine','jade');

app.get('/', (req, res)=>{
	var sql = require('mysql');
	var config = {
		server :'localhost',
		database:'cdactraining',
		user:'root',
		password:''	
	};

	var con = sql.createConnection(config);
	con.query('select * from emptable', (err, results)=>{
		res.render('mysqlData', { list : results });
	})
});

app.listen(1234, ()=>console.log("All is well!!!"));

