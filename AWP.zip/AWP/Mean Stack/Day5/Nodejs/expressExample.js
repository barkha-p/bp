//expressExample.js
//create a Web server for working with static pages....

var express = require('express');
var app = express();
var fs = require('fs');
var path = require('path');

var dir = __dirname;
var filename = path.join(dir,"HomePage.html");
app.get('/', (req, res)=>fs.createReadStream(filename).pipe(res));
app.get('/DAC', (req, res)=>res.send('<h1>DAC Home Page</h1>'))
app.get('/Courses', (req, res)=>res.send('<h1>Course Page</h1>'))

var server = app.listen(1234, ()=>console.log("server is listening at port 1234"));