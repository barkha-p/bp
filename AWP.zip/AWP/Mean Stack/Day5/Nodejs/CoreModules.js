var fs = require('fs');
var util = require('util');
var os = require('os');
var http = require('http');
var path = require('path');
/*var contents = fs.readFileSync("Notes.txt",'utf8');
console.log(contents);*/

//U could read a file asynchronously also....

/*fs.readFile("Notes.txt", 'utf8', (err, data)=>{
	if(err) console.log(err);
	console.log(data);//data is the content of the file that U wish to read...
})

console.log("End of the program");
*************Writing to a File***************** 
var fname ="SampleText.txt";
//fs.writeFile(fname, "Some More Text to write in the file", (Err)=>{ if(Err) console.log(Err)});

fs.appendFile(fname, "\nAdding one more line of code", (err)=> {if(err) console.log(err)});
****************************Reading directory details from Nodejs*******************
var dir = __dirname;//Current directory of the execution App....
console.log(dir);
//All the async functions have certain common features: The std parameters of the function are followed by a callback function. This function will contain the logic of what needs to be done after the execution of the async function.....
//Most of the callback functions take 2 args: 1 for failure and another that holds the return value of the called Function...

fs.readdir(dir, function(err, files){
	files.forEach((v, i)=>{
		fs.stat(v, (err, stats)=>{
			console.log(v);
			console.log(stats)
			console.log("--------------------------------------")
		})
	})
});
************************Util module*******************************
//util module is used to perform string based operations within UR nodejs app

var name = 'Phaniraj';
var salary = 45000;
var strMsg = util.format("My Name is %s with a salary of %d", name, salary);
console.log(strMsg);
//U could still use the JS based string functions in Nodejs....
/////////////////////OS related functions///////////////////////
console.log(os.type());
console.log(os.uptime()/3600);
console.log(os.hostname());
/////////////////////////////////////////////////////*/
//Http module is used to perform Http based functionalities like hosting a web server, processing Http Requests and Responses and creating REST operations...
var dir = __dirname;

var server = http.createServer((req, res)=>{
	if(req.url != '\favicon.ico'){

		if(req.url == "youTube"){
			res.end("http://www.youtube.com");
		}
		var filepath = path.join(dir, req.url);

		//console.log(filepath);
		var contents = fs.readFileSync(filepath, 'utf8');
		res.write(contents);
		res.write("<hr/>");
		res.end("Footer for the page");
	}
});
server.listen(1234);
