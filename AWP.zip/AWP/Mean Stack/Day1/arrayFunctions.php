<!DOCTYPE html>
<html>
<head>
	<title>Using array functions in php</title>
</head>
<body>
	<form action="arrayProcessing.php" method="POST">
		<input type="text" name="fruit" placeholder="Enter the fruit to add">
		<button>Add Fruit</button>
	</form>
</body>
</html>