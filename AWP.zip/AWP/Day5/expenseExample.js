//expenseExample.js
//create a entity to represent each expense...
var expense= function(desc, date, amount){
	this.desc = desc;
	this.date = date;
	this.amount = amount;
}

//Repository to hold all the expenses provided by the user: it will have 5 operations: getAll, find, addNew, update, delete....

//object to represent the expense manager....
var manager = function(){
	data =[
		new expense('Room rent', new Date('03/24/2019'), 6500),
		new expense('ETC Bill', new Date('03/14/2019'), 500),
		new expense('Provisions to room', new Date('03/15/2019'), 1500)
	];//array with 2 or 3 expense objects in it...

	this. addNewExpense = function(ex){
		if(ex == undefined){
			alert("Expense details are not set..")
			return;
		}

		data.push(ex);//adds the object to the bottom of the array...
	}

	this.getAllExpenses = function(){
		return data;
	}

	this.findExpense = function(desc){
		/*var tempList = [];
		data.forEach(function(value, index){
			if(value.desc.includes(desc))
				tempList.push(value);
		})
		return tempList;*/

		return data.filter(function(value){
			return value.desc.includes(desc);
		})//returns a collection/array	

	}

	this.update = function(ex){
		//assumption is desc will not be modified....
		//foreach is forward only and read only, U cannot use foreach for modifying the collection.
		//find method of the Array that takes predicate func to defined the criteria of finding the element from the array...It returns the first element in the array that matches the criteria.
		for (var i = data.length - 1; i >= 0; i--) {
			if(data[i].desc == ex.desc){
				data[i].amount = ex.amount;
				data[i].date = ex.date;
				return;
			}
		}
		throw "Expense not found to update...";
		//to do: replace this above code with find method of the array
	}

	this.delete = function(desc){
		//find the ex matching the desc...
		for (var i = 0; i < data.length; i++) {
			if(data[i].desc == desc){//find the index of the found ex...
				//splice method to be called...
				data.splice(i, 1);
				return;
			}else continue;
		}
		throw "no ex is found to delete";//if no ex is found, throw an error...
	}
}