<?php
require('DB_components.php');
$name=$_POST["name"];
$address=$_POST["address"];
$phone=$_POST["phone"];
insert_hotel($name,$address,$phone);
echo "inserted sucessfully";
?>