<!DOCTYPE html>
<html>
<head>
	<title>ADD_food</title>
</head>
<body>
<form action="food_list_process.php" method="POST">
<input type="text" placeholder="Enter Food name" name="name"/>
<input type="text" placeholder="Enter food price" name="price"/>
<input type="number" placeholder="Enter hotel id" name="hotel_id"/>

<button>ADD_FOOD</button>
</form>
</body>
</html>