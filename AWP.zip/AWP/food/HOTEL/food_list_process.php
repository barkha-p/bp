<?php
require('DB_components.php');
$name=$_POST["name"];
$price=$_POST["price"];

$hotel_id=$_POST["hotel_id"];
insert_food($name,$price,$hotel_id);

echo "inserted sucessfully";
?>