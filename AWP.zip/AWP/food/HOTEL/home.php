<html>
<head>
<title>HOME</title>
</head>
<body>
	<center>
<h1 style="background-color: grey">ORDER_WHAT YOU WANT</h1>

<a href="hotel_list.php">ADD_HOTEL_LIST</a>
<a href="food_list.php">Food_HOTEL_LIST</a>
</center>
</body>
</html>