<?php
function getconenction()
{
	$server='localhost';
	$password='';
	$user='root';
	$database='food_service';
	$con=new mysqli($server,$user,$password,$database);
	return $con;
}
function insert_hotel($name,$address,$phone)
{
	$con=getconenction();
$query=sprintf ("insert into hotel(name,address,contact)values('%s','%s','%s')",$name,$address,$phone);
$con->query($query);
}
function insert_food($name,$price,$hotel_id)
{
	$con=getconenction();
$query=sprintf ("insert into food_menu_detail(food_name,food_price,hotel_id)values('%s','%s','%s')",$name,$price,$hotel_id);
$con->query($query);
}

?>