<!DOCTYPE html>
<html>
<head>
	<title>ADD_HOTEL</title>
</head>
<body>
<form action="hotel_list_process.php" method="POST">
<input type="text" placeholder="Enter Hotel name" name="name"/>
<input type="text" placeholder="Enter Hotel address" name="address"/>
<input type="number" placeholder="Enter Hotel phone number" name="phone"/>
<button>ADD_HOTEL</button>
</form>
</body>
</html>