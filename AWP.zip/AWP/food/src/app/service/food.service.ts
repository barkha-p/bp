import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class FoodService {
   url:string="http://localhost:1239/"
   price:any;
   
   
  constructor(private http:HttpClient) { 
    
  }
  getprice(id:number):any{
    let tempurl=this.url+id;
    return this.http.get(tempurl);
 
  
  }
  getdetail(id:number):any{
  let tempurl=this.url+'hotel/'+id;
  return this.http.get(tempurl);
  }
}


