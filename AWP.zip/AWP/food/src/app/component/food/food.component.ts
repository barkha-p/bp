import { Component, OnInit } from '@angular/core';
import { FoodService } from 'src/app/service/food.service';

@Component({
  selector: 'app-food',
  templateUrl: './food.component.html',
  styleUrls: ['./food.component.css']
})
export class FoodComponent implements OnInit {
price:any;
hotel_id:number=0;
hotel_detail:any;


  constructor(private service:FoodService) { }

  ngOnInit() {
  }
onsubmit()
{
  if(this.hotel_id==0)
  {
    alert("hotel id is not entered");
    return;
  }
  this.service.getprice(this.hotel_id).subscribe((res)=>{this.price=res[0];} );


  this.service.getdetail(this.hotel_id).subscribe((res)=>{this.hotel_detail=res[0];} );
}
}
