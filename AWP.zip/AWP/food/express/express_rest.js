var app=require('express')();
app.use((req,res,next)=>
{
res.header("Access-Control-Allow-Origin","*");
res.header("Acees-Control-Allow-Methods","GET,POST,PUT,DELETE");
res.header("Acees-Control-Allow-Header","#");
next();
})
app.get('/:id',(req,res)=>
{
var sql=require('mysql');
var config=
{
    server:'localhost',
    user:'root',
    password:'',
    database:'food_service'
};

var id=req.params.id;
var con=sql.createConnection(config);
con.query("select * from food_menu_detail where hotel_id="+id,(err,results)=>
    {
      res.send(results);
    });
})

//hotel detail fetch//
app.get('/hotel/:id',(req,res)=>
{
var sql=require('mysql');
var config=
{
    server:'localhost',
    user:'root',
    password:'',
    database:'food_service'
};

var id=req.params.id;
var con=sql.createConnection(config);
con.query("select * from hotel where id="+id,(err,results)=>
    {
      res.send(results);
    });
})
//POST data//
// app.post(query,(e,results)=>
// {
//     var data=req.body;
//     var config=
//     {
//         server:'localhost',
//         user:'root',
//         password:'',
//         database:'food_service'
//     };
//     var con=sql.createConnection(config);
//     if(e)res.send("error");
//     var query=sprintf("insert into hotel(name,address,contact) values('%s','%s','%s')",data.name,data.address,data.contact);
//     res.send("inseration sucessfull");
// })
app.listen(1239,function()
{
    console.log("server running at 1234")
})
